# Linux Mint Cinnamon Mint-Y-Yellow Icons

Only includes the places icons with reference index.theme

### Requirements

This theme doesn't provide application icons, it needs another icon theme to inherit them.
By default this theme will look for the other icons:

Inherits=Mint-Y,Adwaita,gnome,hicolor

This is the way Mint does it for all the other icon colors in Mint-Y.

To Install:
From the directory where the downloaded file is located

sudo unzip -q Mint-Y-Yellow.zip -d /usr/share/icons/
sudo gtk-update-icon-cache /usr/share/icons/Mint-Y-Yellow

