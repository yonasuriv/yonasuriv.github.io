# Matrix-SplashScreen
A SplashScreen for KDE Plasma.

**Wake up, Neo!**